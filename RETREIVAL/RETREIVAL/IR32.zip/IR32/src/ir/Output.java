/*@author- Sushen Kumar Manchukanti
 * sxm135730@utdallas.edu
 * Output class to display results
 * cranfield colection 
 */
package ir;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
//class displays results after the parsing operations
public class Output {
	public static void print(int q,ArrayList<String> termList)
	{
		System.out.println("QUERY : "+ Parser.queries.get(q));
		System.out.println("Query parsed = "+termList.toString());
		int a=1;
		System.out.println("RANK : DOCUMENT : SCORE : HEADLINE");
		for(String key : Parser.sorted_results.keySet())
		{
			System.out.println(a + " : " + key +" : " + Parser.result.get(key) + " : " + Parser.headline.get(Integer.parseInt(key)-1));
			++a;
			if (a>10)
				break;
		}
		System.out.println("");
	}

}
