/*@author- Sushen Kumar Manchukanti
 * sxm135730@utdallas.edu
 * Main program to tokenize words from the
 * cranfield colection 
 */
package ir;
import java.io.*;
import java.sql.Timestamp;
import java.util.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
//class parser which tokenizes the docs.
public class Parser {
	public static int doclen=0;
	public static int maxtf=0;
	public static int collectionsize=0;
	public static int avgdoclen=0;
	public static Stemmer stem = new Stemmer();
	public static File directory;
	public static File file;
	public static ArrayList<String> headline = new ArrayList<String>();
	public static ArrayList<docInfo> docinfo = new 	ArrayList<docInfo>();
	public static HashMap<String,posting> data = new HashMap<String,posting>();
	public static HashMap<String,Integer> temp = new HashMap<String,Integer>();
	public static HashMap<String,Double> result = new HashMap<String,Double>();
	public static ArrayList<String> stopWords = new ArrayList<String>();
	public static ValueComparator bvc =  new ValueComparator(result);
    public static TreeMap<String,Double> sorted_results = new TreeMap<String,Double>(bvc);
    public static ArrayList<String> queries = new ArrayList<String>();
	public static void main(String[] args) 
	{
		// directory pointing to the cranfield folder.
		directory = new File("Cranfield");
		//getting the list of files it contains
		String farray[]=directory.list();
		//displaying time taken before parsing operation
		logic.loadStopWords();
		for(int k=0;k<farray.length;k++) //for each file
		{	
		try
		{
			BufferedReader reader = new BufferedReader(new FileReader(directory.getPath()+"//"+farray[k])); 
			String line;
			while ((line = reader.readLine()) != null) {
				{
					String temp1[]=line.split(">");         //seperating the tags from the text
					for(int i=0;i<temp1.length;i++)			//
					{										//	
						String temp2[]=temp1[i].split("<");	//	
						if(!temp2[0].equals(""))			//
						{
							//System.out.println(temp1[0]);
							String words[]=temp2[0].split(" ");//splitting the line to get each word.
							for(int j=0;j<words.length;j++)
								//System.out.println(words[j]);
								{
								logic.process(words[j],farray[k]);       //call process fucntion present in logic class one each word. 
								}
						}
					}
				}
			}
			reader.close();
		}
		catch(Exception e)										//exceptions
		{
			e.printStackTrace();
		}
		docInfo.max();
		docinfo.add(new docInfo(farray[k],doclen,maxtf));
		temp.clear();
		doclen=0;
		maxtf=0;
		}
		
		for(int k=0;k<farray.length;k++) //for each file
		{	
			File file = new File(directory.getPath()+"//"+farray[k]);
			try{
			Document doc = Jsoup.parse(file, "UTF-8");
			Element title = doc.select("TITLE").first();
			headline.add(title.text());
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		try
		{
			BufferedReader reader = new BufferedReader(new FileReader("queries.txt")); 
			String line;
			while ((line = reader.readLine()) != null) {
				queries.add(line);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		collectionsize = Parser.data.size();
		
		long sum=0; 
		for(int i=0;i<docinfo.size();i++)
			sum = sum+docinfo.get(i).doclen;
		avgdoclen = (int) (sum/1400);
		
		for(int q=0; q<queries.size(); q++)
		{
		String Query = queries.get(q);  
		String terms[] = Query.split(" ");
		ArrayList<String> termList = new ArrayList<String>();
		for(int i=0;i<terms.length;i++)
			{
				String temp = docInfo.parseQuery(terms[i]);
				if(!temp.equals(""))
					termList.add(temp);
			}
		
		for(int i=0;i<termList.size();i++)
		{
			posting post = Parser.data.get(termList.get(i));
			if(!(post==null))
			{
			int df = post.df;
			for(int j=0; j < post.list.size(); j++)
			{
				if(result.containsKey(Integer.toString(post.list.get(j).document)))
				{
					maxtf = docinfo.get(post.list.get(j).document-1).maxtf;  		// -1 because cranfield statrs from 1 and document index is from 0
					doclen = docinfo.get(post.list.get(j).document-1).doclen;
					double W12=(0.4 + 0.6 * (post.list.get(j).tf / (post.list.get(j).tf + 0.5 + 1.5 *(doclen / avgdoclen))) * Math.log (collectionsize / df)/ Math.log (collectionsize));
					Double W1 = result.get(Integer.toString(post.list.get(j).document)) + W12;
					result.put(Integer.toString(post.list.get(j).document),+W1);
				}
				else
				{
					{
					maxtf = docinfo.get(post.list.get(j).document-1).maxtf;			//// -1 because cranfield starts from 1 and document index is from 0
					doclen = docinfo.get(post.list.get(j).document-1).doclen;
					double W2=(0.4 + 0.6 * (post.list.get(j).tf / (post.list.get(j).tf + 0.5 + 1.5 *(doclen / avgdoclen))) * Math.log (collectionsize / df)/ Math.log (collectionsize));
					result.put(Integer.toString(post.list.get(j).document),W2);
					}
				}	
				}
			}
		 }
		sorted_results.putAll(result);	
		Output.print(q,termList);				//calling output function in Output class to print resuls
		result.clear();
		sorted_results.clear();
		}
	}	//end of main	

}		//end of class

//overrides default treemap comparator
class ValueComparator implements Comparator<String> 
{

    Map<String, Double> base;
    public ValueComparator(Map<String, Double> base) {
        this.base = base;
    }

    // Note: this comparator imposes orderings that are inconsistent with equals.    
    public int compare(String a, String b) {
        if (base.get(a) >= base.get(b)) {
            return -1;
        } else {
            return 1;
        } // returning 0 would merge keys
    }
}
