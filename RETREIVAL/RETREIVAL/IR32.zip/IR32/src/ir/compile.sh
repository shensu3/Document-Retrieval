#!/bin/bash

javac -cp .:jsoup-1.8.1.jar Parser.java Stemmer.java Output.java logic.java Output.java docInfo.java

