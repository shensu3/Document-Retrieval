/*@author- Sushen Kumar Manchukanti
 * sxm135730@utdallas.edu
 * Logic class that applies decisions to each token
 * cranfield colection 
 */
package ir;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.Serializable;
import java.util.ArrayList;

public class logic {	
public static void loadStopWords()
{
	try
	{
		BufferedReader reader = new BufferedReader(new FileReader("stopwords.txt")); 
		String line;
		while ((line = reader.readLine()) != null) 
		{
			Parser.stopWords.add(line);
		}
		reader.close();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}
public static void process(String word,String doc)
{
	word=word.trim();				//spaces if any
	word=word.toLowerCase();
	if(word.equals("."))			//taking off the dots
	word=word.replace(".","");
	if(word.endsWith("."))			
	word=word.replace(".","");		
	if(word.endsWith(","))			//deleting trailing commas
	word=word.replace(",","");
	if(word.endsWith("'s"))			//deleting 's
	word=word.replace("'s","");
	if(word.contains("."))
	word=word.replace(".","");
	word=word.replace("/","");
	word=word.replace("\"","");
	word=word.replace(",","");
	word=word.replace("(","");
	word=word.replace(")","");
	word=word.replaceAll("\\d+.*", ""); // eliminate numbers altogether
	word=word.replace("'","");
	if(Parser.stopWords.contains(word))
		word="";
	doc=doc.replace("cranfield","");
	int doc1=Integer.parseInt(doc);
	if(!word.equals(""))			//insert into hashmap.
		{
			Parser.stem.add(word.toCharArray(),word.toCharArray().length);
			Parser.stem.stem();
			word=Parser.stem.toString();
			++Parser.doclen;
			if(Parser.temp.containsKey(word))
			{
				Parser.temp.put(word,Parser.temp.get(word)+1);
			}
			else
			{
				Parser.temp.put(word,1);
			}
			if(!Parser.data.containsKey(word))
			{
				Parser.data.put(word,new posting(1,new doclist(doc1,1)));
			}
			else
			{
				int position=Parser.data.get(word).contains(doc1);
				if(position>=0)
				{
					++Parser.data.get(word).list.get(position).tf;
				}
				else
				{
					Parser.data.get(word).list.add(new doclist(doc1,1));
					++Parser.data.get(word).df;
				}
			}
		}
	}

}

class posting implements Serializable
{
	public int df;
	public ArrayList<doclist> list = new ArrayList<doclist>();
	public posting(int df,doclist list)
	{
		this.df=df;
		this.list.add(list);
	}
	public int contains(int doc)
	{
	int position=-1;
	for(int i=0;i<list.size();i++)
		{
		if(list.get(i).document==doc)
			position=i;
		}
	return position;
	}
	public void printList()
	{
		for(int i=0;i<list.size();i++)
		{
		System.out.print(list.get(i).document);
		System.out.print("|");
		System.out.print(list.get(i).tf);
		System.out.print(" ");
		}
	}
	public void printFile(FileOutputStream out) throws Exception
	{
		for(int i=0;i<list.size();i++)
		{
		out.write(Integer.toString(list.get(i).document).getBytes());
	    out.write("|".getBytes());
		out.write(Integer.toString(list.get(i).tf).getBytes());
		out.write(" ".getBytes());
		}
	}
}
class doclist implements Serializable
{
	int document;
	int tf;
	public doclist(int doc,int tf)
	{
		document=doc;
		this.tf=tf;
	}
}