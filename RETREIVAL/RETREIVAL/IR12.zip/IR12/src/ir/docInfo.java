package ir;

import java.util.HashMap;

public class docInfo {
	public String filename;
	public int doclen;
	public int maxtf;
	public docInfo(String filename,int doclen,int maxtf)
	{
		this.filename=filename;
		this.doclen=doclen;
		this.maxtf=maxtf;
	}
	public static void max()
	{
		for(String  key : Parser.temp.keySet())
		{
			if(Parser.maxtf<Parser.temp.get(key))
				Parser.maxtf=Parser.temp.get(key);
		}
	
	}
	public static String parseQuery(String word)
	{
		word=word.trim();				//spaces if any
		word=word.toLowerCase();
		if(word.equals("."))			//taking off the dots
		word=word.replace(".","");
		if(word.endsWith("."))			
		word=word.replace(".","");		
		if(word.endsWith(","))			//deleting trailing commas
		word=word.replace(",","");
		if(word.endsWith("'s"))			//deleting 's
		word=word.replace("'s","");
		if(word.contains("."))
		word=word.replace(".","");
		word=word.replace("/","");
		word=word.replace("\"","");
		word=word.replace(",","");
		word=word.replace("(","");
		word=word.replace(")","");
		word=word.replaceAll("\\d+.*", ""); // eliminate numbers altogether
		word=word.replace("'","");
		if(Parser.stopWords.contains(word))
			word="";
		if(!word.equals(""))			//insert into hashmap.
		{
			Parser.stem.add(word.toCharArray(),word.toCharArray().length);
			Parser.stem.stem();
			word=Parser.stem.toString();
		}
		return word;
	}
}
