#!/bin/bash
export CORENLP_HOME=/usr/local/corenlp341


java -cp .:jsoup-1.8.1.jar ir.Parser

